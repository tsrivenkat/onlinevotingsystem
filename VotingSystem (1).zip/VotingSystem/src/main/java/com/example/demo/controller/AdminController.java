package com.example.demo.controller;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.model.Leader;
import com.example.demo.model.User;
import com.example.demo.repository.VoteRepository;
import com.example.demo.service.AdminService;
import com.example.demo.service.LeaderService;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private LeaderService leaderService;

	@Autowired
	private VoteRepository voteRepository;
	
	@GetMapping("adminhome")
	public ModelAndView adminhome(HttpServletRequest request) {
	    HttpSession session = request.getSession(false);
	    if (session == null || session.getAttribute("admin") == null) {
	        return new ModelAndView("redirect:/"); // Not logged in
	    }
	    ModelAndView mv = new ModelAndView("adminhome");
	    mv.addObject("message", "Welcome to Admin Dashboard");
	    return mv;
	}

	@GetMapping("adminviewusers")
	public ModelAndView adminviewusers(HttpServletRequest request) {
	    HttpSession session = request.getSession(false);
	    if (session == null || session.getAttribute("admin") == null) {
	        return new ModelAndView("redirect:/");
	    }

	    List<User> users = userService.findAllUsers();
	    List<Map<String, Object>> userInfo = new ArrayList<>();

	    for (User user : users) {
	        Map<String, Object> data = new HashMap<>();
	        data.put("name", user.getName());
	        data.put("email", user.getEmail());
	        data.put("age", user.getAge());
	        data.put("gender", user.getGender());
	        data.put("contact", user.getContact());

	        try {
	            if (user.getPic() != null) {
	                byte[] bytes = user.getPic().getBytes(1, (int) user.getPic().length());
	                String base64 = Base64.getEncoder().encodeToString(bytes);
	                data.put("image", base64);
	            } else {
	                data.put("image", null);
	            }
	        } catch (Exception e) {
	            data.put("image", null);
	        }

	        userInfo.add(data);
	    }

	    ModelAndView mv = new ModelAndView("adminviewusers");
	    mv.addObject("users", userInfo);
	    return mv;
	}

	@GetMapping("adminviewleaders")
	public ModelAndView adminviewleaders(HttpServletRequest request) {
	    HttpSession session = request.getSession(false);
	    if (session == null || session.getAttribute("admin") == null) {
	        return new ModelAndView("redirect:/");
	    }

	    List<Leader> leaders = leaderService.findAllLeaders();
	    List<Map<String, Object>> leaderInfo = new ArrayList<>();

	    for (Leader leader : leaders) {
	        Map<String, Object> data = new HashMap<>();
	        data.put("name", leader.getName());
	        data.put("party", leader.getParty());
	        data.put("constituency", leader.getConstituency());
	        data.put("age", leader.getAge());
	        data.put("gender", leader.getGender());
	        data.put("contact", leader.getContact());

	        try {
	            if (leader.getSymbol() != null) {
	                byte[] bytes = leader.getSymbol().getBytes(1, (int) leader.getSymbol().length());
	                String base64 = Base64.getEncoder().encodeToString(bytes);
	                data.put("symbol", base64);
	            } else {
	                data.put("symbol", null);
	            }
	        } catch (Exception e) {
	            data.put("symbol", null);
	        }

	        leaderInfo.add(data);
	    }

	    ModelAndView mv = new ModelAndView("adminviewleaders");
	    mv.addObject("leaders", leaderInfo);
	    return mv;
	}

	@GetMapping("adminvoteresults")
	public ModelAndView viewVoteResults() {
	    List<Object[]> results = voteRepository.countVotesPerParty();
	    List<Map<String, Object>> formattedResults = new ArrayList<>();

	    for (Object[] row : results) {
	        String party = (String) row[0];
	        Long count = (Long) row[1];
	        Leader leader = leaderService.findLeaderByParty(party);

	        String base64Image = null;
	        if (leader != null && leader.getSymbol() != null) {
	            try {
	                byte[] bytes = leader.getSymbol().getBytes(1, (int) leader.getSymbol().length());
	                base64Image = Base64.getEncoder().encodeToString(bytes);
	            } catch (Exception e) {
	                // Log or skip image
	            }
	        }

	        Map<String, Object> data = new HashMap<>();
	        data.put("party", party);
	        data.put("count", count);
	        data.put("symbol", base64Image);
	        formattedResults.add(data);
	    }

	    ModelAndView mv = new ModelAndView("adminvoteresults");
	    mv.addObject("results", formattedResults);
	    return mv;
	}



}
