package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.User;
import com.example.demo.model.Vote;

@Repository
public interface VoteRepository extends JpaRepository<Vote, Long>{

	boolean existsByVoter(User user);
	@Query("SELECT v.leader.party, COUNT(v) FROM Vote v GROUP BY v.leader.party")
	List<Object[]> countVotesPerParty();


}
