package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Leader;

public interface LeaderService {

	String registerLeader(Leader leader);
    String updateLeaderProfile(Leader leader);
    Leader findLeaderByParty(String party);
	Leader findLeaderByPartyAndPwd(String party, String pwd);
	List<Leader> findAllLeaders();
    
}
