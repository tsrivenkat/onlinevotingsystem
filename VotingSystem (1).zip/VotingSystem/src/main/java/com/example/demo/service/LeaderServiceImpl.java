package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Leader;
import com.example.demo.repository.LeaderRepository;

@Service
public class LeaderServiceImpl implements LeaderService {

    @Autowired
    private LeaderRepository leaderRepository;

    @Override
    public String registerLeader(Leader leader) {
        leaderRepository.save(leader);
        return "Leader registered successfully!";
    }
    

    @Override
    public String updateLeaderProfile(Leader leader) {
        leaderRepository.save(leader);
        return "Leader profile updated successfully!";
    }

	@Override
	public Leader findLeaderByPartyAndPwd(String party, String pwd) {
		return leaderRepository.findByPartyAndPwd(party, pwd);
	}


	@Override
	public Leader findLeaderByParty(String party) {
		return leaderRepository.findByParty(party);
	}


	@Override
	public List<Leader> findAllLeaders() {
		return leaderRepository.findAll();
	}
}