package com.example.demo.controller;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.model.Leader;
import com.example.demo.service.LeaderService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/leader")
public class LeaderController {
	
	@Autowired
	private LeaderService leaderService;
	
	@GetMapping("leaderregister")
	public ModelAndView leaderregister() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("leaderregister");
		return mv;
	}
	
	@GetMapping("leaderlogin")
	public ModelAndView leaderlogin() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("leaderlogin");
		return mv;
	}
	
	@PostMapping("leaderlogin")
	public ModelAndView leaderlogin(HttpServletRequest request) {
	    String party = request.getParameter("party");
	    String pwd = request.getParameter("pwd");
	    Leader leader = leaderService.findLeaderByPartyAndPwd(party, pwd); // Make sure this method exists
	    if (leader != null) {
	        HttpSession session = request.getSession();
	        session.setAttribute("leader", leader);
	        return new ModelAndView("redirect:/leader/leaderhome");
	    } else {
	        ModelAndView mv = new ModelAndView("leaderlogin");
	        mv.addObject("message", "Invalid Party Name or Password!");
	        return mv;
	    }
	}
	
	@PostMapping("insertleader")
	public ModelAndView insertLeader(HttpServletRequest request, @RequestParam("symbol") MultipartFile symbolFile) throws Exception {

	    String name = request.getParameter("name");
	    String party = request.getParameter("party");
	    String pwd = request.getParameter("pwd");
	    String contact = request.getParameter("contact");
	    int age = Integer.parseInt(request.getParameter("age"));
	    String gender = request.getParameter("gender");
	    String constituency = request.getParameter("constituency");

	    Leader leader = new Leader();
	    leader.setName(name);
	    leader.setParty(party);
	    leader.setPwd(pwd);
	    leader.setContact(contact);
	    leader.setAge(age);
	    leader.setGender(gender);
	    leader.setConstituency(constituency);
	    leader.setSymbol(new javax.sql.rowset.serial.SerialBlob(symbolFile.getBytes()));

	    String msg = leaderService.registerLeader(leader); // Implement in your service layer

	    ModelAndView mv = new ModelAndView("leaderregister");
	    mv.addObject("message", msg);
	    return mv;
	}
	
	@GetMapping("leaderhome")
	public ModelAndView leaderhome(HttpServletRequest request) {
	    HttpSession session = request.getSession(false);
	    if (session == null || session.getAttribute("leader") == null) {
	        return new ModelAndView("redirect:/leader/leadersessionexpiry");
	    }
	    return new ModelAndView("leaderhome");
	}
	
	@GetMapping("leaderprofile")
	public ModelAndView leaderprofile(HttpServletRequest request) {
	    HttpSession session = request.getSession(false);
	    if (session == null || session.getAttribute("leader") == null) {
	        return new ModelAndView("redirect:/leader/leadersessionexpiry");
	    }

	    Leader leader = (Leader) session.getAttribute("leader");
	    ModelAndView mv = new ModelAndView("leaderprofile");

	    if (leader.getSymbol() != null) {
	        try {
	            byte[] bytes = leader.getSymbol().getBytes(1, (int) leader.getSymbol().length());
	            String base64 = Base64.getEncoder().encodeToString(bytes);
	            mv.addObject("symbolImage", base64);
	        } catch (Exception e) {
	            mv.addObject("symbolImage", null);
	        }
	    }

	    return mv;
	}


	@PostMapping("updateleaderprofile")
	public ModelAndView updateleaderprofile(HttpServletRequest request, @RequestParam("pic") MultipartFile picFile) {
	    ModelAndView mv = new ModelAndView();
	    try {
	        HttpSession session = request.getSession(false);
	        Leader leader = (Leader) session.getAttribute("leader");

	        if (leader == null) {
	            throw new Exception("Session expired or leader not found");
	        }

	        String name = request.getParameter("name");
	        String contact = request.getParameter("contact");
	        int age = Integer.parseInt(request.getParameter("age"));
	        String gender = request.getParameter("gender");

	        leader.setName(name);
	        leader.setContact(contact);
	        leader.setAge(age);
	        leader.setGender(gender);

	        String msg = leaderService.updateLeaderProfile(leader); // Assumes update logic exists

	        // Update session
	        session.setAttribute("leader", leader);

	        mv.setViewName("leaderprofile");
	        mv.addObject("message", msg);
	    } catch (Exception e) {
	        mv.setViewName("leaderprofile");
	        mv.addObject("message", "Error updating profile: " + e.getMessage());
	    }
	    return mv;
	}


	@GetMapping("leadersessionexpiry")
	public String leadersessionexpiry(HttpServletRequest request, RedirectAttributes redirectAttributes) {
	    HttpSession session = request.getSession();
	    session.invalidate(); // Assuming "leader" is the session attribute
	    redirectAttributes.addFlashAttribute("message", "Session Expired!");
	    return "redirect:/leader/leaderlogout"; // Adjust path as needed
	}

	@GetMapping("leaderlogout")
	public ModelAndView leaderlogout(HttpServletRequest request) {
	    HttpSession session = request.getSession();
	    session.invalidate();
	    return new ModelAndView("leaderlogin"); // View name
	}

}
