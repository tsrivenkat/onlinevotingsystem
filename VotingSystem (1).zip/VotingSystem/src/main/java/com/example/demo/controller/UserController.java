package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.model.Leader;
import com.example.demo.model.User;
import com.example.demo.model.Vote;
import com.example.demo.repository.RegisterRepository;
import com.example.demo.repository.VoteRepository;
import com.example.demo.service.LeaderService;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private LeaderService leaderService;
	
	@Autowired
	private RegisterRepository registerRepository;
	
	@Autowired
	private VoteRepository voteRepository;
	
	@GetMapping("userregister")
	public ModelAndView userregister() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("userregister");
		return mv;
	}
	
	@GetMapping("userlogin")
	public ModelAndView userlogin() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("userlogin");
		return mv;
	}
	
	@PostMapping("userlogin")
	public ModelAndView userlogin(HttpServletRequest request) {
	    String email = request.getParameter("email");
	    String password = request.getParameter("pwd");
	    HttpSession session = request.getSession();

	    if ("admin@gmail.com".equals(email) && "admin".equals(password)) {
	    	session.setAttribute("admin", true); // ✅ Add this line
	        return new ModelAndView("redirect:/adminhome");
	    }

	    User user = userService.findUserByEmailAndPwd(email, password);
	    if (user != null) {
	        session.setAttribute("user", user);
	        return new ModelAndView("redirect:/user/userhome");
	    } else {
	        ModelAndView mv = new ModelAndView("userlogin");
	        mv.addObject("message", "Invalid credentials! Please try again.");
	        return mv;
	    }
	}

	
	@GetMapping("userhome")
	public ModelAndView userhome(HttpServletRequest request) {
	    HttpSession session = request.getSession(false);
	    if (session == null || session.getAttribute("user") == null) {
	        return new ModelAndView("redirect:/user/userlogin");
	    }
	    return new ModelAndView("userhome");
	}

	
	@PostMapping("insertuser")
	public ModelAndView insertUser(HttpServletRequest request, @RequestParam("pic") MultipartFile picFile) throws Exception {

	    String name = request.getParameter("name");
	    String email = request.getParameter("email");
	    String voterid = request.getParameter("voterid");
	    String pwd = request.getParameter("pwd");
	    String contact = request.getParameter("contact");
	    int age = Integer.parseInt(request.getParameter("age"));
	    String gender = request.getParameter("gender");

	    User user = new User();
	    user.setName(name);
	    user.setEmail(email);
	    user.setVoterid(voterid);
	    user.setPwd(pwd);
	    user.setContact(contact);
	    user.setAge(age);
	    user.setGender(gender);
	    user.setPic(new javax.sql.rowset.serial.SerialBlob(picFile.getBytes()));

	    String msg = userService.registerUser(user);

	    ModelAndView mv = new ModelAndView("userregister");
	    mv.addObject("message", msg);
	    return mv;

	}
	
	@GetMapping("userprofile")
	public ModelAndView userprofile(HttpSession session) {
	    ModelAndView mv = new ModelAndView();

	    if (session == null || session.getAttribute("user") == null) {
	        mv.setViewName("redirect:/user/usersessionexpiry");
	        return mv;
	    }

	    mv.setViewName("userprofile");
	    User user = (User) session.getAttribute("user");

	    if (user.getPic() != null) {
	        try {
	            byte[] bytes = user.getPic().getBytes(1, (int) user.getPic().length());
	            String base64Image = Base64.getEncoder().encodeToString(bytes);
	            mv.addObject("profileImage", base64Image);
	        } catch (Exception e) {
	            mv.addObject("profileImage", null);
	        }
	    }
	    return mv;
	}



	@PostMapping("updateuserprofile")
	public ModelAndView updateuserprofile(HttpServletRequest request, @RequestParam("pic") MultipartFile picFile) {
	    ModelAndView mv = new ModelAndView();
	    try {
	        String email = request.getParameter("email");
	        String name = request.getParameter("name");
	        String contact = request.getParameter("contact");
	        int age = Integer.parseInt(request.getParameter("age"));
	        String gender = request.getParameter("gender");

	        User user = userService.findUserByEmail(email);
	        if (user == null)
	            throw new Exception("User not found");

	        user.setName(name);
	        user.setContact(contact);
	        user.setAge(age);
	        user.setGender(gender);

	        if (!picFile.isEmpty())
	            user.setPic(new javax.sql.rowset.serial.SerialBlob(picFile.getBytes()));

	        String msg = userService.updateUserProfile(user);

	        HttpSession session = request.getSession();
	        session.setAttribute("user", user);

	        mv.setViewName("userprofile");
	        mv.addObject("message", msg);
	    } catch (Exception e) {
	        mv.setViewName("userprofile");
	        mv.addObject("message", "Error updating profile: " + e.getMessage());
	    }
	    return mv;
	}
	
	@GetMapping("uservote")
	public String uservote(Model model, HttpSession session) {
		if (session == null || session.getAttribute("user") == null) {
	        return "redirect:/user/usersessionexpiry";
	    }
		
	    List<Leader> leaders = leaderService.findAllLeaders();
	    List<Map<String, Object>> leaderInfo = new ArrayList<>();

	    for (Leader leader : leaders) {
	        Map<String, Object> data = new HashMap<>();
	        data.put("name", leader.getName());
	        data.put("party", leader.getParty());
	        data.put("constituency", leader.getConstituency());

	        try {
	            if (leader.getSymbol() != null) {
	                byte[] bytes = leader.getSymbol().getBytes(1, (int) leader.getSymbol().length());
	                String base64 = Base64.getEncoder().encodeToString(bytes);
	                data.put("symbol", base64);
	            }
	        } catch (Exception e) {
	            data.put("symbol", null);
	        }

	        leaderInfo.add(data);
	    }

	    model.addAttribute("leaders", leaderInfo);
	    model.addAttribute("user", session.getAttribute("user"));
	    return "uservote";
	}

	
	@PostMapping("uservote")
	public String uservote(@RequestParam String party, HttpSession session, Model model) {
	    User user = (User) session.getAttribute("user");
	    
	    if (user == null) {
	        return "redirect:/user/userlogin";
	    }

	    if (voteRepository.existsByVoter(user)) {
	        model.addAttribute("message", "You have already voted.");
	        return "uservote";
	    }

	    Leader leader = leaderService.findLeaderByParty(party);
	    if (leader == null) {
	        model.addAttribute("message", "Invalid leader selected.");
	        return "uservote";
	    }

	    Vote vote = new Vote();
	    vote.setLeader(leader);
	    vote.setVoter(user);
	    vote.setTimestamp(LocalDateTime.now().toString());

	    voteRepository.save(vote);

	    model.addAttribute("message", "Your vote has been submitted successfully.");
	    return "uservote";
	}


	
	@GetMapping("usersessionexpiry")
	public String usersessionexpiry(HttpServletRequest request, RedirectAttributes redirectAttributes) {
	    HttpSession session = request.getSession();
	    session.invalidate(); // Assuming "user" is the session attribute
	    redirectAttributes.addFlashAttribute("message", "Session Expired!");
	    return "redirect:/user/userlogin"; // Adjust path as needed
	}

	@GetMapping("userlogout")
	public ModelAndView userlogout(HttpServletRequest request) {
	    HttpSession session = request.getSession();
	    session.invalidate();
	    return new ModelAndView("userlogin"); // View name
	}


}
